<?php
require_once __DIR__ . '/inc/bootstrap.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  header('Location: ' . base_path('index.php'));
  exit;
}

$stmt = db()->prepare("SELECT * FROM products WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $id]);
$product = $stmt->fetch();

if (!$product) {
  http_response_code(404);
  echo "Produk tidak ditemukan.";
  exit;
}

$store = store_info();
require __DIR__ . '/inc/header.php';
?>
<div class="row" style="align-items:flex-start">
  <div style="flex:1; min-width:280px">
    <div class="card" style="overflow:hidden">
      <div class="img" style="aspect-ratio: 4/3;">
        <?php if (!empty($product['image']) && file_exists(__DIR__ . '/uploads/' . $product['image'])): ?>
          <img src="<?= e(base_path('uploads/' . $product['image'])) ?>" alt="<?= e($product['name']) ?>">
        <?php else: ?>
          <div class="muted">No Image</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div style="flex:1.3; min-width:300px">
    <h1 style="margin-top:0"><?= e($product['name']) ?></h1>
    <div class="price" style="font-size:20px; margin-bottom:10px"><?= e(format_rupiah($product['price'])) ?></div>
    <?php if (!empty($product['description'])): ?>
      <div class="card" style="padding:14px; margin-bottom:12px">
        <div style="white-space:pre-wrap"><?= e($product['description']) ?></div>
      </div>
    <?php endif; ?>

    <?php if (!empty($store['whatsapp'])): ?>
      <?php
        $msgParts = [];
        $msgParts[] = 'Halo ' . ($store['name'] !== '' ? $store['name'] : 'Admin') . ',';
        $msgParts[] = 'saya mau tanya/pesan produk:';
        $msgParts[] = $product['name'] . ' (ID #' . (int)$product['id'] . ')';
        if ($product['price'] !== null && $product['price'] !== '') {
          $msgParts[] = 'Harga: ' . format_rupiah($product['price']);
        }
        $msg = implode("\n", $msgParts);
      ?>
      <a class="btn primary" target="_blank" rel="noopener" href="<?= e(wa_link_with_text($store['whatsapp'], $msg)) ?>">
        Order via WhatsApp
      </a>
    <?php endif; ?>
    <a class="btn" href="<?= e(base_path('index.php')) ?>">Kembali</a>

    <div class="small" style="margin-top:10px">
      Dibuat: <?= e((string)$product['created_at']) ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/inc/footer.php'; ?>
