<?php
require_once __DIR__ . '/inc/bootstrap.php';

$store = store_info();
$products = [];
try {
  $stmt = db()->query("SELECT id, name, price, image, created_at FROM products ORDER BY created_at DESC");
  $products = $stmt->fetchAll();
} catch (Throwable $e) {
  $products = [];
}
require __DIR__ . '/inc/header.php';
?>
<div class="hero">
  <h1>Produk <?= e($store['name']) ?></h1>
  <p class="muted">Klik produk untuk lihat detail. Anda bisa tambah/hapus produk lewat admin panel.</p>
</div>

<?php if (empty($products)): ?>
  <div class="alert">Belum ada produk. Masuk ke <a href="<?= e(base_path('admin/index.php')) ?>">Admin</a> untuk menambahkan produk.</div>
<?php else: ?>
  <div class="grid">
    <?php foreach ($products as $p): ?>
      <a class="card" href="<?= e(base_path('product.php?id=' . (int)$p['id'])) ?>">
        <div class="img">
          <?php if (!empty($p['image']) && file_exists(__DIR__ . '/uploads/' . $p['image'])): ?>
            <img src="<?= e(base_path('uploads/' . $p['image'])) ?>" alt="<?= e($p['name']) ?>">
          <?php else: ?>
            <div class="muted">No Image</div>
          <?php endif; ?>
        </div>
        <div class="body">
          <h3><?= e($p['name']) ?></h3>
          <div class="price"><?= e(format_rupiah($p['price'])) ?></div>
          <div class="small">ID Produk: #<?= (int)$p['id'] ?></div>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/inc/footer.php'; ?>
