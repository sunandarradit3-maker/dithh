DiTz Store - Simple PHP + MySQL (cPanel ready)
================================================

Fitur:
- Halaman publik: daftar produk, detail produk, kontak
- Admin panel: login, tambah/edit/hapus produk, upload foto, atur info toko (nama/WA/email)
- Aman dasar: password_hash, prepared statement PDO, CSRF token pada form admin

Kebutuhan server:
- PHP 7.4+ (disarankan PHP 8.x)
- MySQL/MariaDB
- Ekstensi PHP: PDO MySQL

Cara install di cPanel (ringkas):
1) Buat Database + User MySQL di cPanel
2) Import file install/schema.sql via phpMyAdmin
3) Copy file inc/config.sample.php menjadi inc/config.php lalu isi kredensial DB
4) Upload semua file/folder ini ke public_html (atau folder domain)
5) Pastikan folder uploads/ writable (permission 755/775 sesuai server)
6) Buat akun admin (1x): buka /install/create_admin.php
   - Setelah sukses: hapus folder install/ (biar aman)
7) Login admin: buka /admin
   - Email awal: sunandarradit3@gmail.com
   - Password awal: ChangeMe123!
   Segera ganti password: lewat menu Admin → Account.

Ganti password admin (via phpMyAdmin):
- Tabel: admins
- Kolom: password_hash harus berupa hash bcrypt dari password baru.
Cara cepat: gunakan file install/hash_password.php (jalankan sekali), atau pakai PHP snippet:
  <?php echo password_hash('PASSWORD_BARU', PASSWORD_DEFAULT); ?>

Catatan:
- Setelah instalasi sukses, Anda boleh hapus folder install/ untuk keamanan tambahan.
- Jika upload gambar error, pastikan php.ini limits (upload_max_filesize & post_max_size) cukup.

Kontak yang tampil di website:
- Nama: DiTz store
- WhatsApp: +6287739435496 (https://wa.me/6287739435496)
- Email: sunandarradit3@gmail.com
