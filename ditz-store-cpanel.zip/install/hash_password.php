<?php
// Utility: generate bcrypt hash for a password (does NOT touch database)
$password = $_GET['p'] ?? '';
?>
<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Hash Password</title></head>
<body style="font-family:system-ui,Arial,sans-serif; padding:20px">
<h2>Generate password_hash()</h2>
<form>
  <label>Password:</label><br>
  <input type="text" name="p" value="<?= htmlspecialchars((string)$password, ENT_QUOTES, 'UTF-8') ?>" style="padding:10px; width:320px">
  <button type="submit" style="padding:10px">Generate</button>
</form>

<?php if ($password !== ''): ?>
  <h3>Hasil</h3>
  <pre><?= htmlspecialchars(password_hash((string)$password, PASSWORD_DEFAULT), ENT_QUOTES, 'UTF-8') ?></pre>
<?php endif; ?>

<p>Catatan: setelah selesai, hapus file ini untuk keamanan.</p>
</body>
</html>
