<?php
require_once __DIR__ . '/../inc/bootstrap.php';

// Safety: Only run if there is no admin yet
try {
  $stmt = db()->query("SELECT COUNT(*) AS c FROM admins");
  $row = $stmt->fetch();
  $count = (int)($row['c'] ?? 0);
} catch (Throwable $e) {
  http_response_code(500);
  echo "DB error: " . e($e->getMessage());
  exit;
}

if ($count > 0) {
  echo "Admin sudah ada. Untuk keamanan, file ini tidak akan membuat admin baru. Anda bisa hapus folder install/.";
  exit;
}

$defaultEmail = "sunandarradit3@gmail.com";
$defaultPassword = 'ChangeMe123!';

$hash = password_hash($defaultPassword, PASSWORD_DEFAULT);

$stmt = db()->prepare("INSERT INTO admins (email, password_hash) VALUES (:email, :hash)");
$stmt->execute([':email' => $defaultEmail, ':hash' => $hash]);

echo "<h2>Admin berhasil dibuat ✅</h2>";
echo "<p><b>Email:</b> " . e($defaultEmail) . "</p>";
echo "<p><b>Password:</b> " . e($defaultPassword) . "</p>";
echo "<p>Silakan login di <a href='" . e(base_path("admin/index.php")) . "'>/admin</a> lalu ganti password di menu Account.</p>";
echo "<p><b>PENTING:</b> Hapus folder <code>install/</code> setelah selesai.</p>";
