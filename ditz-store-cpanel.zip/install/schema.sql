-- DiTz Store schema (MySQL/MariaDB)
-- Import via phpMyAdmin

CREATE TABLE IF NOT EXISTS admins (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  price DECIMAL(12,2) NULL,
  description TEXT NULL,
  image VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  `key` VARCHAR(100) NOT NULL,
  `value` TEXT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default settings (can be edited in Admin > Settings)
INSERT INTO settings (`key`, `value`) VALUES
('store_name', "DiTz store"),
('store_whatsapp', "+6287739435496"),
('store_email', "sunandarradit3@gmail.com")
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);

-- Next step:
-- 1) Upload files, configure inc/config.php
-- 2) Open /install/create_admin.php once to create admin user (then delete install/ folder)
