<?php
declare(strict_types=1);

if (!function_exists('str_starts_with')) {
  function str_starts_with(string $haystack, string $needle): bool {
    return $needle === '' || strpos($haystack, $needle) === 0;
  }
}


function e(string $value): string {
  return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function base_path(string $path = ''): string {
  $base = $GLOBALS['config']['app']['base_path'] ?? '';
  return rtrim($base, '/') . '/' . ltrim($path, '/');
}

function format_rupiah($amount): string {
  if ($amount === null || $amount === '') return '-';
  $num = (float)$amount;
  return 'Rp ' . number_format($num, 0, ',', '.');
}

function csrf_token(): string {
  if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
  }
  return $_SESSION['_csrf'];
}

function csrf_check(): void {
  $token = $_POST['_csrf'] ?? '';
  if (!$token || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
    http_response_code(403);
    echo "CSRF token invalid.";
    exit;
  }
}

function is_admin_logged_in(): bool {
  return !empty($_SESSION['admin_id']);
}

function require_admin(): void {
  if (!is_admin_logged_in()) {
    header('Location: ' . base_path('admin/index.php'));
    exit;
  }
}

function flash_set(string $key, string $message): void {
  $_SESSION['_flash'][$key] = $message;
}

function flash_get(string $key): ?string {
  if (!isset($_SESSION['_flash'][$key])) return null;
  $msg = $_SESSION['_flash'][$key];
  unset($_SESSION['_flash'][$key]);
  return $msg;
}

function setting_get(string $key, ?string $fallback = null): ?string {
  try {
    $stmt = db()->prepare("SELECT `value` FROM settings WHERE `key` = :k LIMIT 1");
    $stmt->execute([':k' => $key]);
    $row = $stmt->fetch();
    if ($row && array_key_exists('value', $row)) return (string)$row['value'];
  } catch (Throwable $e) {
    // settings table might not exist yet; ignore
  }
  return $fallback;
}

function store_info(): array {
  $default = $GLOBALS['config']['store'] ?? ['name' => 'Store', 'whatsapp' => '', 'email' => ''];
  return [
    'name' => setting_get('store_name', $default['name'] ?? 'Store'),
    'whatsapp' => setting_get('store_whatsapp', $default['whatsapp'] ?? ''),
    'email' => setting_get('store_email', $default['email'] ?? ''),
  ];
}

function wa_digits(string $wa): string {
  $digits = preg_replace('/\D+/', '', $wa);
  if (str_starts_with($digits, '0')) {
    $digits = '62' . substr($digits, 1);
  }
  if (!str_starts_with($digits, '62')) {
    $digits = '62' . ltrim($digits, '0');
  }
  return $digits;
}

function wa_link(string $wa): string {
  $d = wa_digits($wa);
  return 'https://wa.me/' . $d;
}

function wa_link_with_text(string $wa, string $text): string {
  $base = wa_link($wa);
  $text = trim($text);
  if ($text === '') return $base;
  return $base . '?text=' . rawurlencode($text);
}

function upload_image(array $file, string $destDir): array {
  // returns [ok(bool), filename|null, error|null]
  if (empty($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
    return [true, null, null]; // no upload
  }

  if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
    return [false, null, 'Upload error code: ' . (int)$file['error']];
  }

  $maxBytes = 2 * 1024 * 1024; // 2MB
  if (($file['size'] ?? 0) > $maxBytes) {
    return [false, null, 'Ukuran file terlalu besar. Maks 2MB.'];
  }

  $tmp = $file['tmp_name'] ?? '';
  if (!$tmp || !is_uploaded_file($tmp)) {
    return [false, null, 'File upload tidak valid.'];
  }

  $info = @getimagesize($tmp);
  if ($info === false) {
    return [false, null, 'File bukan gambar yang valid.'];
  }

  $mime = $info['mime'] ?? '';
  $allowed = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/webp' => 'webp',
  ];
  if (!isset($allowed[$mime])) {
    return [false, null, 'Tipe gambar tidak didukung. Gunakan JPG/PNG/WEBP.'];
  }

  if (!is_dir($destDir)) {
    if (!@mkdir($destDir, 0755, true)) {
      return [false, null, 'Gagal membuat folder upload.'];
    }
  }

  $rand = bin2hex(random_bytes(12));
  $ext = $allowed[$mime];
  $filename = $rand . '.' . $ext;
  $destPath = rtrim($destDir, '/\\') . DIRECTORY_SEPARATOR . $filename;

  if (!@move_uploaded_file($tmp, $destPath)) {
    return [false, null, 'Gagal menyimpan file upload.'];
  }

  return [true, $filename, null];
}
