<?php
$store = store_info();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($store['name']) ?></title>
  <link rel="stylesheet" href="<?= e(base_path('assets/css/style.css')) ?>">
</head>
<body>
  <div class="nav">
    <div class="brand"><a href="<?= e(base_path('index.php')) ?>"><?= e($store['name']) ?></a></div>
    <div class="navlinks">
      <a href="<?= e(base_path('index.php')) ?>">Produk</a>
      <a href="<?= e(base_path('contact.php')) ?>">Kontak</a>
      <a href="<?= e(base_path('admin/index.php')) ?>" class="badge">Admin</a>
    </div>
  </div>
  <div class="container">
