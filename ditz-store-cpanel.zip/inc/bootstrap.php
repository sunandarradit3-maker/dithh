<?php
// Common bootstrap for all pages

declare(strict_types=1);

session_start();

$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
  http_response_code(500);
  echo "Config missing. Please copy inc/config.sample.php to inc/config.php and fill DB credentials.";
  exit;
}

$config = require $configFile;

date_default_timezone_set($config['app']['timezone'] ?? 'Asia/Jakarta');

// Error handling: log errors, don't display in production
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
if (!is_dir(__DIR__ . '/../logs')) {
  @mkdir(__DIR__ . '/../logs', 0755, true);
}
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');


// Friendly error pages
set_exception_handler(function (Throwable $e) {
  error_log('[EXCEPTION] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
  http_response_code(500);
  echo "Terjadi kesalahan pada server. Silakan coba lagi atau cek konfigurasi.";
  exit;
});

set_error_handler(function (int $severity, string $message, string $file, int $line) {
  // Convert errors to exceptions so we can handle consistently
  throw new ErrorException($message, 0, $severity, $file, $line);
});


// Load helpers
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
