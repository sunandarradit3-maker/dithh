<?php
// Copy this file to config.php and fill your database credentials

return [
  'db' => [
    'host' => 'localhost',
    'name' => 'CPANEL_DB_NAME',
    'user' => 'CPANEL_DB_USER',
    'pass' => 'CPANEL_DB_PASSWORD',
    'charset' => 'utf8mb4',
  ],

  // Default store info (can be edited later in Admin > Settings)
  'store' => [
    'name' => "DiTz store",
    'whatsapp' => "+6287739435496",
    'email' => "sunandarradit3@gmail.com",
  ],

  // App
  'app' => [
    'timezone' => 'Asia/Jakarta',
    // Set to true if your website is inside a subfolder, e.g. '/ditz-store'
    'base_path' => '',
  ],
];
