  <div class="footer">
    <div>© <?= date('Y') ?> <?= e($store['name']) ?>. All rights reserved.</div>
  </div>
  </div>
</body>
</html>
