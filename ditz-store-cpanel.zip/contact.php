<?php
require_once __DIR__ . '/inc/bootstrap.php';
$store = store_info();
require __DIR__ . '/inc/header.php';
?>
<h1>Kontak</h1>

<div class="form">
  <div class="field">
    <label>Nama Toko</label>
    <div><?= e($store['name']) ?></div>
  </div>

  <div class="field">
    <label>WhatsApp</label>
    <?php if (!empty($store['whatsapp'])): ?>
      <div>
        <a class="btn primary" target="_blank" rel="noopener" href="<?= e(wa_link($store['whatsapp'])) ?>">
          <?= e($store['whatsapp']) ?>
        </a>
      </div>
      <div class="small">Link: <?= e(wa_link($store['whatsapp'])) ?></div>
    <?php else: ?>
      <div class="muted">Belum diatur.</div>
    <?php endif; ?>
  </div>

  <div class="field">
    <label>Email</label>
    <?php if (!empty($store['email'])): ?>
      <div><a href="mailto:<?= e($store['email']) ?>"><?= e($store['email']) ?></a></div>
    <?php else: ?>
      <div class="muted">Belum diatur.</div>
    <?php endif; ?>
  </div>

  <div class="alert">
    Info ini bisa Anda ubah dari Admin Panel → Settings.
  </div>
</div>

<?php require __DIR__ . '/inc/footer.php'; ?>
