<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$isEdit = $id > 0;

$name = '';
$price = '';
$description = '';
$image = '';

if ($isEdit) {
  $stmt = db()->prepare("SELECT * FROM products WHERE id = :id LIMIT 1");
  $stmt->execute([':id' => $id]);
  $p = $stmt->fetch();
  if (!$p) {
    flash_set('err', 'Produk tidak ditemukan.');
    header('Location: ' . base_path('admin/products.php'));
    exit;
  }
  $name = (string)$p['name'];
  $price = (string)$p['price'];
  $description = (string)($p['description'] ?? '');
  $image = (string)($p['image'] ?? '');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $name = trim((string)($_POST['name'] ?? ''));
  $price = trim((string)($_POST['price'] ?? ''));
  $description = trim((string)($_POST['description'] ?? ''));

  if ($name === '') {
    flash_set('err', 'Nama produk wajib diisi.');
    header('Location: ' . base_path('admin/product_form.php' . ($isEdit ? '?id=' . $id : '')));
    exit;
  }

  // Upload (optional)
  [$ok, $filename, $uploadErr] = upload_image($_FILES['image'] ?? [], __DIR__ . '/../uploads');
  if (!$ok) {
    flash_set('err', $uploadErr ?? 'Gagal upload gambar.');
    header('Location: ' . base_path('admin/product_form.php' . ($isEdit ? '?id=' . $id : '')));
    exit;
  }

  try {
    if ($isEdit) {
      $newImage = $image;
      if ($filename) {
        // remove old file if exists
        if ($image && file_exists(__DIR__ . '/../uploads/' . $image)) {
          @unlink(__DIR__ . '/../uploads/' . $image);
        }
        $newImage = $filename;
      }

      $stmt = db()->prepare("UPDATE products SET name=:name, price=:price, description=:desc, image=:img, updated_at=NOW() WHERE id=:id");
      $stmt->execute([
        ':name' => $name,
        ':price' => $price !== '' ? $price : null,
        ':desc' => $description !== '' ? $description : null,
        ':img' => $newImage !== '' ? $newImage : null,
        ':id' => $id,
      ]);
      flash_set('ok', 'Produk berhasil diupdate.');
    } else {
      $stmt = db()->prepare("INSERT INTO products (name, price, description, image, created_at, updated_at) VALUES (:name, :price, :desc, :img, NOW(), NOW())");
      $stmt->execute([
        ':name' => $name,
        ':price' => $price !== '' ? $price : null,
        ':desc' => $description !== '' ? $description : null,
        ':img' => $filename,
      ]);
      flash_set('ok', 'Produk berhasil ditambahkan.');
    }
  } catch (Throwable $e) {
    flash_set('err', 'DB error: ' . $e->getMessage());
  }

  header('Location: ' . base_path('admin/products.php'));
  exit;
}

require __DIR__ . '/inc/admin_header.php';
?>
<h1><?= $isEdit ? 'Edit' : 'Tambah' ?> Produk</h1>

<div class="form">
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">

    <div class="field">
      <label>Nama Produk</label>
      <input type="text" name="name" required value="<?= e($name) ?>" placeholder="Contoh: Hoodie Premium">
    </div>

    <div class="row">
      <div class="field">
        <label>Harga (angka saja)</label>
        <input type="number" name="price" value="<?= e($price) ?>" placeholder="Contoh: 150000" min="0">
        <div class="small">Kosongkan jika ingin tidak menampilkan harga.</div>
      </div>

      <div class="field">
        <label>Foto Produk (JPG/PNG/WEBP max 2MB)</label>
        <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
        <?php if ($isEdit && $image): ?>
          <div class="small">Foto saat ini: <a target="_blank" rel="noopener" href="<?= e(base_path('uploads/' . $image)) ?>">lihat</a></div>
        <?php endif; ?>
      </div>
    </div>

    <div class="field">
      <label>Deskripsi</label>
      <textarea name="description" placeholder="Tulis deskripsi produk..."><?= e($description) ?></textarea>
    </div>

    <button class="btn primary" type="submit">Simpan</button>
    <a class="btn" href="<?= e(base_path('admin/products.php')) ?>">Batal</a>
  </form>
</div>

<?php require __DIR__ . '/inc/admin_footer.php'; ?>
