<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

$ok = flash_get('ok');
$err = flash_get('err');

$store = store_info();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $name = trim((string)($_POST['store_name'] ?? ''));
  $wa = trim((string)($_POST['store_whatsapp'] ?? ''));
  $email = trim((string)($_POST['store_email'] ?? ''));

  if ($name === '') {
    flash_set('err', 'Nama toko wajib diisi.');
    header('Location: ' . base_path('admin/settings.php'));
    exit;
  }

  try {
    $pdo = db();
    $pdo->beginTransaction();

    $pairs = [
      'store_name' => $name,
      'store_whatsapp' => $wa,
      'store_email' => $email,
    ];

    foreach ($pairs as $k => $v) {
      $stmt = $pdo->prepare("INSERT INTO settings (`key`, `value`) VALUES (:k, :v)
                             ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
      $stmt->execute([':k' => $k, ':v' => $v]);
    }

    $pdo->commit();
    flash_set('ok', 'Settings berhasil disimpan.');
  } catch (Throwable $e) {
    try { db()->rollBack(); } catch (Throwable $e2) {}
    flash_set('err', 'DB error: ' . $e->getMessage());
  }

  header('Location: ' . base_path('admin/settings.php'));
  exit;
}

require __DIR__ . '/inc/admin_header.php';
?>
<h1>Settings Toko</h1>

<?php if ($ok): ?><div class="alert ok"><?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>

<div class="form">
  <form method="post">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">

    <div class="field">
      <label>Nama Toko</label>
      <input type="text" name="store_name" value="<?= e($store['name']) ?>" required>
    </div>

    <div class="field">
      <label>WhatsApp</label>
      <input type="text" name="store_whatsapp" value="<?= e($store['whatsapp']) ?>" placeholder="+62812xxxxxxx">
      <div class="small">Akan otomatis dibuat link wa.me</div>
    </div>

    <div class="field">
      <label>Email</label>
      <input type="email" name="store_email" value="<?= e($store['email']) ?>" placeholder="email@domain.com">
    </div>

    <button class="btn primary" type="submit">Simpan</button>
  </form>

  <div class="alert" style="margin-top:12px">
    Tips: password admin bisa diganti di menu <b>Account</b>.
  </div>
</div>

<?php require __DIR__ . '/inc/admin_footer.php'; ?>
