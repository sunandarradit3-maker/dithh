<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

$ok = flash_get('ok');
$err = flash_get('err');

$stmt = db()->query("SELECT id, name, price, image, created_at FROM products ORDER BY created_at DESC");
$products = $stmt->fetchAll();

require __DIR__ . '/inc/admin_header.php';
?>
<h1>Produk</h1>

<?php if ($ok): ?><div class="alert ok"><?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>

<div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:10px">
  <a class="btn primary" href="<?= e(base_path('admin/product_form.php')) ?>">+ Tambah Produk</a>
</div>

<table class="table">
  <thead>
    <tr>
      <th style="width:80px">ID</th>
      <th>Nama</th>
      <th style="width:160px">Harga</th>
      <th style="width:160px">Tanggal</th>
      <th style="width:180px">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($products)): ?>
      <tr><td colspan="5" class="muted">Belum ada produk.</td></tr>
    <?php else: ?>
      <?php foreach ($products as $p): ?>
        <tr>
          <td>#<?= (int)$p['id'] ?></td>
          <td>
            <b><?= e($p['name']) ?></b><br>
            <span class="small">
              <?php if (!empty($p['image'])): ?>📷 ada foto<?php else: ?>📷 tidak ada foto<?php endif; ?>
            </span>
          </td>
          <td><?= e(format_rupiah($p['price'])) ?></td>
          <td class="small"><?= e((string)$p['created_at']) ?></td>
          <td>
            <a class="btn" href="<?= e(base_path('admin/product_form.php?id=' . (int)$p['id'])) ?>">Edit</a>
            <form method="post" action="<?= e(base_path('admin/product_delete.php')) ?>" style="display:inline" onsubmit="return confirm('Hapus produk ini?');">
              <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="btn danger" type="submit">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    <?php endif; ?>
  </tbody>
</table>

<?php require __DIR__ . '/inc/admin_footer.php'; ?>
