<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

$count = 0;
try {
  $stmt = db()->query("SELECT COUNT(*) AS c FROM products");
  $row = $stmt->fetch();
  $count = (int)($row['c'] ?? 0);
} catch (Throwable $e) {
  $count = 0;
}

require __DIR__ . '/inc/admin_header.php';
?>
<h1>Dashboard</h1>

<div class="alert ok">
  Login sebagai: <b><?= e((string)($_SESSION['admin_email'] ?? '')) ?></b>
</div>

<div class="card" style="padding:14px">
  <div class="row">
    <div>
      <div class="muted">Total Produk</div>
      <div style="font-size:28px; font-weight:800"><?= (int)$count ?></div>
    </div>
    <div style="display:flex; align-items:flex-end; gap:10px; justify-content:flex-end">
      <a class="btn primary" href="<?= e(base_path('admin/product_form.php')) ?>">+ Tambah Produk</a>
      <a class="btn" href="<?= e(base_path('admin/products.php')) ?>">Kelola Produk</a>
    </div>
  </div>
</div>

<?php require __DIR__ . '/inc/admin_footer.php'; ?>
