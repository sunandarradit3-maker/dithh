<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ' . base_path('admin/products.php'));
  exit;
}

csrf_check();
$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
  flash_set('err', 'ID tidak valid.');
  header('Location: ' . base_path('admin/products.php'));
  exit;
}

$stmt = db()->prepare("SELECT image FROM products WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $id]);
$p = $stmt->fetch();

$stmt = db()->prepare("DELETE FROM products WHERE id = :id");
$stmt->execute([':id' => $id]);

if ($p && !empty($p['image'])) {
  $path = __DIR__ . '/../uploads/' . $p['image'];
  if (file_exists($path)) @unlink($path);
}

flash_set('ok', 'Produk berhasil dihapus.');
header('Location: ' . base_path('admin/products.php'));
exit;
