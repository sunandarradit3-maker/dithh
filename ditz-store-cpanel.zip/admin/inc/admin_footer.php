  <div class="footer">
    <div class="small">Admin Panel — <?= date('Y') ?>.</div>
  </div>
  </div>
</body>
</html>
