<?php
$store = store_info();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin - <?= e($store['name']) ?></title>
  <link rel="stylesheet" href="<?= e(base_path('assets/css/style.css')) ?>">
</head>
<body>
  <div class="nav">
    <div class="brand"><a href="<?= e(base_path('admin/dashboard.php')) ?>">Admin</a> <span class="badge"><?= e($store['name']) ?></span></div>
    <div class="navlinks">
      <a href="<?= e(base_path('admin/products.php')) ?>">Produk</a>
      <a href="<?= e(base_path('admin/settings.php')) ?>">Settings</a>
      <a href="<?= e(base_path('admin/account.php')) ?>">Account</a>
      <a href="<?= e(base_path('index.php')) ?>">Lihat Website</a>
      <a href="<?= e(base_path('admin/logout.php')) ?>" class="badge">Logout</a>
    </div>
  </div>
  <div class="container">
