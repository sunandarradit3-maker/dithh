<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

$ok = flash_get('ok');
$err = flash_get('err');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $current = (string)($_POST['current_password'] ?? '');
  $new = (string)($_POST['new_password'] ?? '');
  $confirm = (string)($_POST['confirm_password'] ?? '');

  if ($new === '' || strlen($new) < 8) {
    flash_set('err', 'Password baru minimal 8 karakter.');
    header('Location: ' . base_path('admin/account.php'));
    exit;
  }
  if ($new !== $confirm) {
    flash_set('err', 'Konfirmasi password tidak sama.');
    header('Location: ' . base_path('admin/account.php'));
    exit;
  }

  $adminId = (int)($_SESSION['admin_id'] ?? 0);
  $stmt = db()->prepare("SELECT password_hash FROM admins WHERE id=:id LIMIT 1");
  $stmt->execute([':id' => $adminId]);
  $row = $stmt->fetch();

  if (!$row || !password_verify($current, (string)$row['password_hash'])) {
    flash_set('err', 'Password saat ini salah.');
    header('Location: ' . base_path('admin/account.php'));
    exit;
  }

  $hash = password_hash($new, PASSWORD_DEFAULT);
  $stmt = db()->prepare("UPDATE admins SET password_hash=:h WHERE id=:id");
  $stmt->execute([':h' => $hash, ':id' => $adminId]);

  flash_set('ok', 'Password berhasil diganti.');
  header('Location: ' . base_path('admin/account.php'));
  exit;
}

require __DIR__ . '/inc/admin_header.php';
?>
<h1>Account</h1>

<?php if ($ok): ?><div class="alert ok"><?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>

<div class="form">
  <form method="post">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">

    <div class="field">
      <label>Email</label>
      <input type="email" value="<?= e((string)($_SESSION['admin_email'] ?? '')) ?>" disabled>
      <div class="small">Untuk mengganti email admin: lakukan lewat phpMyAdmin (tabel <code>admins</code>)</div>
    </div>

    <div class="field">
      <label>Password Saat Ini</label>
      <input type="password" name="current_password" required>
    </div>

    <div class="row">
      <div class="field">
        <label>Password Baru</label>
        <input type="password" name="new_password" required>
      </div>
      <div class="field">
        <label>Konfirmasi Password Baru</label>
        <input type="password" name="confirm_password" required>
      </div>
    </div>

    <button class="btn primary" type="submit">Ganti Password</button>
  </form>
</div>

<?php require __DIR__ . '/inc/admin_footer.php'; ?>
