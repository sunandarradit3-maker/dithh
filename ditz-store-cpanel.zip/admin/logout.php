<?php
require_once __DIR__ . '/../inc/bootstrap.php';
session_unset();
session_destroy();
header('Location: ' . base_path('admin/index.php'));
exit;
